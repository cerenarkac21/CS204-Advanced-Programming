
// MFCApplication2Dlg.h : header file
//

#pragma once
#include "afxwin.h"


// CMFCApplication2Dlg dialog
class CMFCApplication2Dlg : public CDialogEx
{
// Construction
public:
	CMFCApplication2Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MFCAPPLICATION2_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedButton1();
	CEdit input1;
	CEdit input2;
	CEdit input3;
	CListBox list;
	int radio1;
	int radio2;
	int radio3;
	CButton check;
	CComboBox comboBox;
	CButton button;
	afx_msg void OnBnClickedCheck1();
	int groupedRadioButtons;
	afx_msg void OnEnChangeEdit3();
	afx_msg void OnEnChangeEdit4();
	CEdit dummy;
	afx_msg void OnEnChangedummyid();
	afx_msg void OnCbnSelchangeCombo1();
};
